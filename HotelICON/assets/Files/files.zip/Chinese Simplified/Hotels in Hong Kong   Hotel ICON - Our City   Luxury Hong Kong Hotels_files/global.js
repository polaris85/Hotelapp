﻿var isIE = (navigator.appName.indexOf("Microsoft") > -1);
var isIE6 = false /*@cc_on || @_jscript_version < 5.7 @*/;
var isIE7 = false /*@cc_on || @_jscript_version == 5.7 @*/;
var isIE8 = false /*@cc_on || @_jscript_version == 5.8 @*/;
var isIELower9 = false /*@cc_on || @_jscript_version <= 5.8 @*/;
var isAndroid = (navigator.userAgent.toLowerCase().search('android') > -1);
var isIpad = checkIsIphoneIpad();
var isMobile = (isIE)?	false:checkMobile();
var ieVersion;
if (/MSIE (\d+\.\d+);/.test(navigator.userAgent))	ieVersion = new Number(RegExp.$1);
var d = document;
var timer=false;
//var serverTime = '2012-08-20';
var serverTimeArray = serverTime.split('-');
var todayDate = new Date(serverTimeArray[0], (serverTimeArray[1]-1), serverTimeArray[2]);

var div = document.createElement("div");
div.innerHTML = "<!--[if lt IE 9]><i></i><![endif]-->";
isIELower9 = (div.getElementsByTagName("i").length == 1);


/*var monthNamesAry = new Array();

if(currentLang == 'ru') monthNamesAry = ['ЯНВ','ФЕВ','МАР','АПР','МАЙ','ИЮН','ИЮЛ','АВГ','СЕН','ОКТ','НОЯ','ДЕК'];
if(currentLang == 'zh-tw') monthNamesAry = ['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'];
if(currentLang == 'zh-cn') monthNamesAry = ['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'];
if(currentLang == 'eng') monthNamesAry = ['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'];
if(currentLang == '') monthNamesAry = ['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'];*/


function NewWindow(mypage, myname, w, h, scroll,resizable)
{
	var winl = (screen.width - w) / 2;
	var wint = (screen.height - h) / 2;
	winprops = 'height='+h+',width='+w+',top='+wint+',left='+winl+',scrollbars='+scroll+',resizable='+resizable+','
	win = window.open(mypage, myname, winprops)
	win.self.focus()
	if (parseInt(navigator.appVersion) >= 4) { win.window.focus(); }
}

function createImg(src, alt, w, h, link, t, className)
{
	var img = d.createElement('img');
	if (src)	img.setAttribute('src', src);
	if (alt)	img.setAttribute('alt', alt);
	if (w)	img.setAttribute('width', w);
	if (h)	img.setAttribute('height', h);
	if (className)	img.className = className;

	if (link)
	{
		img.setAttribute('border', 0);

		var a = d.createElement('a');
		a.setAttribute('href', link);
		if (t && typeof(t) != 'undefined')	a.setAttribute('target', t);
		a.appendChild(img);
		return a;
	}
	else
	{
		return img;
	}
}

function createA(link, t, txt, id, className)
{
	var a = d.createElement('a');
	if (link)	a.setAttribute('href', link);
	if (t && typeof(t) != 'undefined')	a.setAttribute('target', t);

	//if (txt)	a.appendChild(d.createTextNode(txt));
	if (txt)	a.innerHTML = txt;
	if (id)	a.setAttribute('id', id);
	if (className)	a.className = className;

	return a;
}

function createDiv(id, className, txt)
{
	var div = d.createElement('div');
	if (id)	div.setAttribute('id', id);
	if (className)	div.className = className;
	//if (txt)	div.appendChild(d.createTextNode(txt));
	if (txt)	div.innerHTML = txt;
	return div;
}

function createSpan(id, className, txt)
{
	var span = d.createElement('span');
	if (id)	span.setAttribute('id', id);
	if (className)	span.className = className;
	//if (txt)	div.appendChild(d.createTextNode(txt));
	if (txt)	span.innerHTML = txt;
	return span;
}

function createTag(tag, id, className)
{
	var div = d.createElement(tag);
	if (id)	div.setAttribute('id', id);
	if (className)	div.className = className;
	return div;
}

function createInput(name, type, value, className)
{
	var input = d.createElement('input');
	if (name)	input.setAttribute('name', name);
	if (type)	input.setAttribute('type', type);
	if (value)	input.setAttribute('value', value);
	if (className)	input.className = className;
	return input;
}

function setChildNodes(obj, tagName)
{
	var array = new Array();

	for (var i=0; i<obj.childNodes.length; i++)
	{
		if (tagName)
		{
			//alert(obj.childNodes[i].tagName)
			if (obj.childNodes[i].tagName != tagName)	continue;
		}
		if (obj.childNodes[i].toString().toLowerCase().indexOf('text') >= 0)	continue;
		array.push(obj.childNodes[i]);
	}

	return array;
}

function getElementsByClassName(p, c, selected)
{
	var array = new Array();
	var tags = p.getElementsByTagName('*');

	for (var i=0; i<tags.length; i++)
	{
		if (!tags[i].className)	continue;
		if (selected)
		{
			if (tags[i].className.indexOf(c) >= 0)	array.push(tags[i]);
		}
		else
		{
			if (tags[i].className == c)	array.push(tags[i]);
		}
	}

	return array;
}

function getElementByRel(parent, obj)
{
	var a = parent.getElementsByTagName('a');
	for (var i=0; i<a.length; i++)
	{
		if (a[i].rel == obj)
		{
			return a[i];
		}
	}
}

function GetParam(name)
{
	var start=location.search.indexOf("?"+name+"=");
	if (start<0) start=location.search.indexOf("&"+name+"=");
 	if (start<0) return '';
 	start += name.length+2;
 	var end=location.search.indexOf("&",start)-1;
 	if (end<0) end=location.search.length;
 	var result=location.search.substring(start,end);
 	var result='';
 	for(var i=start;i<=end;i++)
 	{
 		var c=location.search.charAt(i);
 		result=result+(c=='+'?' ':c);
 	}
 	//alert(unescape(result));
 	return unescape(result);
}

function addEvent (o, t, f)
{
	removeEvent (o, t, f);
	if (o.attachEvent) o.attachEvent('on'+ t, f);
	else o.addEventListener(t, f, false);
};

function removeEvent (o, t, f)
{
	if (o.detachEvent) o.detachEvent('on'+ t, f);
	else o.removeEventListener(t, f, false);
};

function addZero(num)
{
	if (num < 10)	num = '0' + num;
	return	num;
}

function setFieldFocus()
{
	var input = d.getElementsByTagName('input');

	for (var i=0; i<input.length; i++)
	{
		if (input[i].type != 'text')		continue;
		if (input[i].defaultValue == '')	continue;

		input[i].onfocus = function()
		{
			if (this.value == this.defaultValue)	this.value = '';
		}

		input[i].onblur = function()
		{
			if (this.value == '')	this.value = this.defaultValue;
		}
	}
}

function checkIsIpad() {
    var pda_user_agent_list = new Array("iPad");
    var user_agent = navigator.userAgent.toString();
    for (var i = 0; i < pda_user_agent_list.length; i++) {
        if (user_agent.indexOf(pda_user_agent_list[i]) >= 0) {
            return true;
        }
    }
    return false;
}

function checkIsIphoneIpad()
{
	var pda_user_agent_list = new Array("iPhone", "iPod", "iPad"/*, "GTB"*/);
	var pda_app_name_list = new Array("Microsoft Pocket Internet Explorer");

	var user_agent = navigator.userAgent.toString();
	for (var i=0; i<pda_user_agent_list.length; i++) {
		if (user_agent.indexOf(pda_user_agent_list[i]) >= 0) {
			return true;
		}
	}
	var appName = navigator.appName.toString();
	for (var i=0; i<pda_app_name_list.length; i++) {
		if (user_agent.indexOf(pda_app_name_list[i]) >= 0) {
			return true;
		}
	}

	return false;
}
//
$(document).ready(function()
{
	if (checkIsIpad())
	{
	    //$(window).on('orientationchange', function (event)
		window.addEventListener('orientationchange', function (event)
		{
		updateOrientation();
		});
		updateOrientation();
	}
});

function updateOrientation() {

    var screenWidth = 0;
    if (window.innerWidth > 0) {
        screenWidth = window.innerWidth;
    }
    else if (screen.width > 0) {
        screenWidth = screen.width;
    }

    //if (screenWidth < 1024)
	if (screenWidth < 768)
        return;

    var viewport = 1024;
    var viewportContent = "width=" + viewport;

    var viewport = document.querySelector("meta[name=viewport]");
    viewport.setAttribute('content', viewportContent);
}

function checkMobile()
{
	var pda_user_agent_list = new Array("2.0 MMP", "240320", "AvantGo","BlackBerry", "Blazer",
			"Cellphone", "Danger", "DoCoMo", "Elaine/3.0", "EudoraWeb", "hiptop", "IEMobile", "KYOCERA/WX310K", "LG/U990",
			"MIDP-2.0", "MMEF20", "MOT-V", "NetFront", "Newt", "Nintendo Wii", "Nitro", "Nokia",
			"Opera Mini", "Opera Mobi",
			"Palm", "Playstation Portable", "portalmmm", "Proxinet", "ProxiNet",
			"SHARP-TQ-GX10", "Small", "SonyEricsson", "Symbian OS", "SymbianOS", "TS21i-10", "UP.Browser", "UP.Link",
			"Windows CE", "WinWAP", "Android", "iPhone", "iPod", "iPad", "Windows Phone", "HTC"/*, "GTB"*/);
	var pda_app_name_list = new Array("Microsoft Pocket Internet Explorer");

	var user_agent = navigator.userAgent.toString();
	for (var i=0; i<pda_user_agent_list.length; i++) {
		if (user_agent.indexOf(pda_user_agent_list[i]) >= 0) {
			return true;
		}
	}
	var appName = navigator.appName.toString();
	for (var i=0; i<pda_app_name_list.length; i++) {
		if (user_agent.indexOf(pda_app_name_list[i]) >= 0) {
			return true;
		}
	}

	return false;
}

function addIpadCSS()
{
	var cssLink = document.createElement('link');
	cssLink.setAttribute('rel', 'stylesheet');
	cssLink.setAttribute('type', 'text/css');
	cssLink.setAttribute('href', 'css/ipad.css');
	d.getElementsByTagName('head')[0].appendChild(cssLink);

	//d.body.className += ' iPad';
}

function changeLanguage(target)
{
	var array = new Array('en', 'zh-tw', 'zh-cn', 'ja-jp', 'ko-kr', 'ru-ru');
	var lang;
	var url = top.location.href;
	var count = 0;
	//if (top.location.hash)	url = top.location.href.replace(top.location.hash, '');	
	//var langParam = GetParam('sc_lang');
	
	/* for (var i=0; i<array.length; i++)
	{
		if (url.indexOf(langParam) < 0)
		{
			url = url.replace(langParam, '' + target + '');
		}
		else
		{
			url = 'http://' + top.location.hostname + top.location.pathname + '?sc_lang=' + target + top.location.hash;
		}
		break;
	} */
	
	
	for (var i=0; i<array.length; i++)
	{
		var lang;
		
		if (url.indexOf('/' + array[i] + '/') > 0)
		{
			lang = array[i];
			url = url.replace('/' + lang + '/', '/' + target + '/');
			count++;
			break;
		}
	}
	if (count == 0)
	{
		lang = target;
		url = 'http://' + top.location.hostname + '/' + target + top.location.pathname + top.location.hash;
	}
	//console.log(url);
	//return;
	window.top.location.href = url;
}

function detectTouch(obj, config)
{
    if (!config)	config =
	{
		min_move_x: 20,
		wipeLeft: function(x) {},
		wipeRight: function(x) {},
		min_move_y: 20,
		wipeTop: function(y) {},
		wipeBottom: function(y) {},
		preventDefaultEvents: true
	};

	var startX;
	var startY;
	var isMoving = false;

	function cancelTouch()
	{
		this.removeEventListener('touchmove', onTouchMove);
		startX = null;
		startY = null;
		isMoving = false;
	}

	function onTouchMove(e)
	{
		if (config.preventDefaultEvents)
		{
			e.preventDefault();
		}
		if (isMoving)
		{
			var x = e.touches[0].pageX;
			var dx = startX - x;
			if (Math.abs(dx) >= config.min_move_x)
			{
				cancelTouch();
				if (dx > 0)
				{
					config.wipeLeft(dx);
				}
				else
				{
					config.wipeRight(dx);
				}
			}
			var y = e.touches[0].pageY;
			var dy = startY - y;
			if (Math.abs(dy) >= config.min_move_y)
			{
				cancelTouch();
				if (dy > 0)
				{
					config.wipeTop(dy);
				}
				else
				{
					config.wipeBottom(dy);
				}
			}
		}
	}

	function onTouchStart(e)
	{
		if (e.touches.length == 1)
		{
			startX = e.touches[0].pageX;
			startY = e.touches[0].pageY;
			isMoving = true;
			this.addEventListener('touchmove', onTouchMove, false);
		}
	}

	obj.addEventListener('touchstart', onTouchStart, false);
}

function tabs(trigger,content,defaultItem){
	$(trigger).each(function(i){
		$(this).click(function(e){
			if ($(this)[0].className.indexOf('active') >= 0)	return;
			e.preventDefault();
			$(trigger).removeClass('active');
			$(this).addClass('active');
			$(content).hide().eq(i).fadeIn();
			$(trigger).parent().parent().find('.yearContainer a').removeClass('active');
			$(this).parent().parent().find('.yearContainer a').addClass('active');
		});
	});
	
	if(defaultItem!=null)
		$(trigger).eq(defaultItem).click();
}

function setLastItem() {
	$('#sectionContainer > div').first().css({paddingTop:90});
	$(document).ready(function() {
		$('.galleryNav .in > div').last().addClass('last');
	});
	$('.galleryContent .desc p:last-child').css({paddingBottom:0});
}

function showLang() {
	$('.langSelect').hover(
		function () {
			$(this).addClass('active');
			$(this).find('.langList').show();
		},
		function () {
			$(this).removeClass('active');
			$(this).find('.langList').hide();
		}			
	);
}

function makeReservation() {
	$('.reservationDate .dateInput').find('input').each(function(i){
		$(this).focus(function(){
			$('.reservationDate .dateInput').removeClass('active');
			$(this).parent().addClass('active');
		});
		$(this).blur(function(){
			$(this).parent().removeClass('active');
			//$('.datepickerArrival, datepickerDeparture').datepicker('hide');
		});
	});
	showArrival();
	showDeparture();
	
//alert(todayDate);
	function showArrival(){
		$('.datepickerArrival').datepicker({
			numberOfMonths: 2,
			stepMonths: 2,
			showAnim: '',
			//showCurrentAtPos: 0,
			minDate: todayDate,
			dateFormat: 'dd/mm/yy',
			monthNames: monthNamesAry,//['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'],
			dayNamesMin: ['S','M','T','W','T','F','S'],
			beforeShow: function(textbox, instance){
				instance.dpDiv.appendTo($('.calContainer'));
				if (!$('.datepickerDeparture').val())	return;
				$(this).datepicker( 'option', 'maxDate', $('.datepickerDeparture').datepicker('getDate') );
			},
			beforeShowDay: function(beforeDate) {
				if ($('.datepickerDeparture').val() && !$('.datepickerArrival').val()){
					if (beforeDate.getTime() == $('.datepickerDeparture').datepicker('getDate').getTime()){
						return [true, "selected", ""];
					} 
				}
				//console.log("beforeShowDay..."+beforeDate);
				if ($('.datepickerArrival').val() && $('.datepickerDeparture').val()){
					
					if (beforeDate <= $('.datepickerDeparture').datepicker('getDate') && beforeDate >= $(this).datepicker('getDate')) {
						return [true, "highlighted", ""];
					}
				};
				
				return [true, "", ""];
			},
			onSelect: function(selectedDate, instance){
				if ($('.datepickerArrival').val() && $('.datepickerDeparture').val()){
					$(this).data('datepicker').inline = true;
				}
			},
			onClose: function(selectedDate, instance){
				$(this).data('datepicker').inline = false;
				if (!$(this).val())	return;
				//alert(selectedDate);
				$('.datepickerDeparture').datepicker( 'option', 'minDate', selectedDate );
				if ($('.datepickerDeparture').val())	return;
				$('.datepickerDeparture').datepicker('show');
			}
			
		});
	}
	function showDeparture(){
		$('.datepickerDeparture').datepicker({
			numberOfMonths: 2,
			stepMonths: 2,
			showAnim: '',
			minDate: todayDate,
			dateFormat: 'dd/mm/yy',
			monthNames: monthNamesAry, //['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'],
			dayNamesMin: ['S','M','T','W','T','F','S'],	
			beforeShow: function(textbox, instance){
				instance.dpDiv.appendTo($('.calContainer'));
				if (!$('.datepickerArrival').val())	return;
				$(this).datepicker( 'option', 'minDate', $('.datepickerArrival').datepicker('getDate') );
				if ($('.datepickerArrival').val() && $('.datepickerDeparture').val()){
					if ($(this).datepicker('getDate').getMonth() - $('.datepickerArrival').datepicker('getDate').getMonth() == 1){
						$(this).datepicker( 'option', 'showCurrentAtPos', 1 );
						return;
					}
				} 
			},
			beforeShowDay: function(afterDate) {
				if ($('.datepickerArrival').val() && !$('.datepickerDeparture').val()){
					if (afterDate.getTime() == $('.datepickerArrival').datepicker('getDate').getTime()){
						return [true, "selected", ""];
					} 
				}
				
				if ($('.datepickerArrival').val() && $('.datepickerDeparture').val()){
					if (afterDate >= $('.datepickerArrival').datepicker('getDate') && afterDate <= $(this).datepicker('getDate')) {
						return [true, "highlighted", ""];
					}
				}
				
				return [true, "", ""];
			},
			onSelect: function(selectedDate, instance){
				if ($('.datepickerArrival').val() && $('.datepickerDeparture').val()){
					//console.log($('.datepickerDeparture').data('datepicker'));
					$('.datepickerDeparture').data('datepicker').settings.showCurrentAtPos = 0;
					$('.datepickerDeparture').data('datepicker').inline = true;
				}
				//console.log($(this).data('datepicker'));
				//console.log($('.datepickerArrival').data('datepicker'));
			},
			onClose: function(selectedDate, instance){
				$(this).data('datepicker').inline = false;
				if (!$(this).val())	return;
				$('.datepickerArrival').datepicker( 'option', 'maxDate', selectedDate );
				if ($('.datepickerArrival').val())	return;
				$('.datepickerArrival').datepicker('show');
			}
		});
	}
}

function homeInit(){
	ourStoryGallery();
	stylishGallery();
	tabs('.iconicNav a','.iconicGallery > li',0);
}

function ourStoryGallery(){
	//var curSlideNum;
	//var index = 0;
	$('#our-story .galleryContainer ul').each(function(i){
		if ($(this).find('li').length <= 1) {
			$(this).parent().find('.controls').hide();
			return;
		}
		$(this).cycle({ 
			fx: 'scrollHorz', 
			timeout: slideShowTime,
			//startingSlide: index,
			speed: 1000,
			delay:500,
			slideResize: false,
			prev: $(this).parent().find('.prev'),
			next: $(this).parent().find('.next'),
			pager: $(this).parent().find('.galleryNav .center .middle .in'),
			activePagerClass: 'active',			
			pagerAnchorBuilder: pagerFactory,
			after: updateCurSlide
		});
	});
	
	$('#textSlideShow').each(function(i){
		$(this).cycle({
			fx:'fade',
			timeout: slideShowTime,
			//startingSlide: index,
			speed: 1000,
			delay:500,
			slideResize: false,
			cleartype:true,
			cleartypeNoBg:true,	
			prev: $('.galleryContainer .controls .prev'),
			next: $('.galleryContainer .controls .next'),		
			pager: $('.galleryContainer .galleryNav .center .middle .in'),		
			pagerAnchorBuilder: function(i) {
	        return $('.galleryContainer .galleryNav .center .middle .in a:eq('+i+')');
	    }				
		});
	});
	
	function updateCurSlide(){
		//alert(slideShowTime);
	}
/*	function updateCurSlide(curr,next,opts){
		curSlideNum =  opts.currSlide;
	 $('#textSlideShow').cycle(curSlideNum);
	// alert(slideShowTime);
	}	*/
	
	$('#syncControl a').click(function(e){
		
	});
	
	function pagerFactory(idx, slide) {
		return '<div><a href="#">'+($(slide).find('img').attr('alt'))+'</a></div>';
	};
}

function stylishGallery(){
	$('#stylish-experience .galleryContainer ul.galleryIntro').each(function(i){
		if ($(this).find('li').length <= 1) {
			$(this).parent().find('.controls').hide();
			return;
		}
		$(this).cycle({ 
			fx: 'scrollHorz', 
			timeout: 5000,
			speed: 400,
			pause: true,
			slideResize: false,
			pagerAnchorBuilder: function(pager, activeIndex) {return}, 
			pager: $('.stylishGalleryNav ul'),
			updateActivePagerLink: updateActivePager 
		});
	});
	
	function updateActivePager(pager, activeIndex) {
		$('.stylishGalleryNav ul').find('li:eq('+activeIndex+')').addClass('active').siblings().removeClass('active');
	};

	$('.stylishGalleryNav li').each(function(i){
		$(this).hover(
			function () {
				$(this).parent().parent().parent().find('ul.galleryIntro').cycle('pause');
		    $(this).parent().parent().parent().find('ul.galleryIntro').cycle(i);
		    $(this).parent().find('li').removeClass('active');
		    $(this).addClass('active');
		    return false;
			},
			function () {
				$(this).parent().parent().parent().find('ul.galleryIntro').cycle('resume');
			}			
		)
		$(this).click(function() {
			window.location.href = $(this).find('a').attr('href');
		});
	});
}

function photoGallery(){
	$('.galleryContainer ul.galleryIntro').each(function(i){
		if ($(this).find('li').length <= 1) {
			$(this).parent().parent().find('.controls').hide();
			//$(this).parent().find('.galleryNav').hide();
			return;
		}
		$(this).cycle({ 
			fx: 'scrollHorz', 
			timeout: 0,
			speed: 400,
			slideResize: false,
			onPrevNextEvent: hideDLBtn,
			after: showDLBtn,
			prev: $(this).parent().parent().find('.prev'),
			next: $(this).parent().parent().find('.next'),
			pager: $(this).parent().find('.galleryNav .center .middle .in'),
			activePagerClass: 'active',
			pagerAnchorBuilder: pagerFactory
		});
	});
	
	function hideDLBtn() {
		if (isIELower9) {
			$('.downloadImg').css({visibility:'hidden'});
		}
	};
	
	function showDLBtn() {
		if (isIELower9) {
			$('.downloadImg').css({visibility:'visible'});
		}
	};
	
	function pagerFactory(idx, slide) {
		return '<div><a href="#">'+(idx+1)+'</a></div>';
	};
	if($('.scroll-pane')) $('.scroll-pane').jScrollPane();
}

function theMarketGallery(){
	$('.galleryContainer ul.galleryIntro').each(function(i){
		if ($(this).find('li').length <= 1) {
			$(this).parent().find('.controls').hide();
			//$(this).parent().find('.galleryNav').hide();
			return;
		}
		$(this).cycle({ 
			fx: 'scrollHorz', 
			timeout: 0,
			speed: 400,
			slideResize: false,
			before: hideImageDetails,
			after: showImageDetails,
			prev: $(this).parent().find('.prev'),
			next: $(this).parent().find('.next'),
			pager: $(this).parent().find('.galleryNav .center .middle .in'),
			activePagerClass: 'active',
			pagerAnchorBuilder: pagerFactory
		});
	});
	
	function hideImageDetails(){
		$('.galleryContent .desc .content').css({visibility:'hidden'});
		if (isIELower9) {
			$('.galleryContent .left').css({visibility:'hidden'});
			$('.galleryContent .desc').css({visibility:'hidden'});
		}	
	}
	
	function showImageDetails(){
		genScroll();
		if (isIELower9) {
			$('.galleryContent .left').css({visibility:'visible'});
			$('.galleryContent .desc').css({visibility:'visible'});
		}	
	}
	
	function pagerFactory(idx, slide) {
		return '<div><a href="#">'+(idx+1)+'</a></div>';
	};	
	
	function genScroll(){
		if($('.scroll-pane'))	$('.scroll-pane').jScrollPane();
		setTimeout(function(){$('.galleryContent .desc .content').css({visibility:'visible'});}, 100);
	}

}

function iconicGallery(){

	var defaultIconic = parseInt(GetParam('iconic'));
	var defaultItem = parseInt(GetParam('item'));
	
	$('.galleryContainer ul.galleryIntro').each(function(i){
		$(this).cycle({ 
			fx: 'scrollHorz', 
			timeout: 0,
			speed: 400,
			slideResize: false,
			before: hideContent,
			after: genScroll,
			prev: $(this).parent().find('.prev'),
			next: $(this).parent().find('.next'),
			pager: $(this).parent().find('.galleryNav .center .middle .in'),
			activePagerClass: 'active',
			pagerAnchorBuilder: pagerFactory
		});
	
		function pagerFactory(idx, slide) {
			return '<div><a href="#">'+(idx+1)+'</a></div>';
		};
		
		$(this).find('a.backToAllIcons').click(function(){
			$(this).parent().parent().parent().parent().parent().cycle(0);
		});
		
		$(this).find('.iconicThumb li').each(function(i){
			$(this).click(function(){
				$(this).parent().parent().parent().parent().cycle(i+1);
			});
		});
	});
	function hideContent(currSlideElement, nextSlideElement, options, forwardFlag){
		if ($(nextSlideElement).index() == 0){
			$('.iconicTitle').show();
		} else {
			$('.iconicTitle').hide();
		}
		$(this).find('.galleryContent .desc .content').css({visibility:'hidden'});
	}
	
	function genScroll(){
		if($('.scroll-pane'))	$('.scroll-pane').jScrollPane();
		setTimeout(function(){$('.galleryContent .desc .content').css({visibility:'visible'});}, 100);
	}
	
	$('.galleryContainer ul.galleryIntro').eq(defaultIconic).cycle(defaultItem);
	if (defaultIconic)
	{
		tabs('.iconicNav a','.iconicGalleryContainer > .galleryItem',defaultIconic);
	} else {
		tabs('.iconicNav a','.iconicGalleryContainer > .galleryItem',0);
	}
}
	
function genEventsCalendar(){
	var eventsToday = new Date(todayDate.getFullYear(), todayDate.getMonth(), 1);
	//eventsToday.setTime(todayDate.getTime());
	
	//var month = new Array('JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC');
	for(var i=0; i<12; i++) {
		if (eventsToday.getFullYear() == serverTimeArray[0])
		{
			genCalendar('.thisYear', i);
		} else {
			genCalendar('.nextYear', i);
		}
	}
	
	var thisW = $('.thisYear .monthContainer').find('a').outerWidth();	
	$('.thisYear, .thisYear .yearContainer').css({width : $('.thisYear .monthContainer').find('a').length * thisW});
	
	var nextW = $('.nextYear .monthContainer').find('a').outerWidth();	
	$('.nextYear, .nextYear .yearContainer').css({width : $('.nextYear .monthContainer').find('a').length * thisW});
	
	
	function genCalendar(year, num){
		var monthLink = createA('javascript:;', '', month[eventsToday.getMonth()]);		
		$(monthLink).appendTo(year + ' .monthContainer');
		
		if ($(year + ' .yearContainer').find('a').length == 0){
			var yearLink = createA('javascript:;', '', eventsToday.getFullYear());
			$(yearLink).appendTo(year + ' .yearContainer');
		}
		
		eventsToday.setMonth(eventsToday.getMonth()+1);
		//console.log(todayDate.getFullYear(), ' : ', todayDate.getMonth());
	}
	tabs('.eventContainer .monthContainer > a', '.eventPhotoContainer > div', 0);
}

function showForms(){
	var defaultValue = $('.search').val();
	$('.btnKeepMeInformed, .goBtn').click(function() {
		//$(this).colorbox({inline:true, overlayClose:false, transition:'fade', href:$('.formsContainer.keepMeInformed')});
		var mail = '';
		if ($('.search').val() != defaultValue || $('.search').val().indexOf('@') !== -1) mail = $('.search').val();
		$(this).colorbox({inline:true, overlayClose:false, transition:'fade', href:'/forms/KeepMeInformed.aspx?mail='+mail, iframe:true, width: "600px", height: "550px", scrolling:false});
	});
	$('.btnRegister').click(function() {
		//$(this).colorbox({inline:true, overlayClose:false, transition:'fade', href:$('.formsContainer.register')});
		$(this).colorbox({inline:true, overlayClose:false, transition:'fade', href:'/forms/Register.aspx', iframe:true, width: "600px", height: "540px", scrolling:false});
	});
	$('.btnWantToKnowMore').click(function() {
		//$(this).colorbox({inline:true, overlayClose:false, transition:'fade', href:$('.formsContainer.wantToKnowMore')});
		//$(this).colorbox({inline:true, overlayClose:false, transition:'fade', href:'/forms/Events.aspx', iframe:true, width: "600px", height: "760px", scrolling:false});
		$(this).colorbox({inline:true, overlayClose:false, transition:'fade', href:'/forms/Events.aspx', iframe:true, width: "600px", height: "760px", scrolling:false
		});
	});
	
	$('#beforeLogin .btnConnect').click(function(){
		$(this).colorbox({inline:true, overlayClose:false, transition:'fade', href:$('#socialMediaConnection'),
		onOpen: setColorBoxPlacement
		});	
	});
	
	function setColorBoxPlacement(){
		$('#cboxOverlay').appendTo($('#aspForm'));
		$('#colorbox').appendTo($('#aspForm'));
	}
}

function setKeepMeInformedForm(myform){
		
	validateForm(myform);

	$('.keepMeInformed .custselect').dropkick({
		startSpeed : 0,
		change: function(value, label) {
			$(this).parent().find('input').val(value);
			//$('form.'+myform).validate().element($(this).parent().find('input')); 
		}
	});
	
	$('.dobpicker').datepicker({
		monthNames: monthNamesAry, //['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'],
		changeYear: true,
		changeMonth: true,
		yearRange: (todayDate.getFullYear() - 100) + ':' + todayDate.getFullYear(),
		showAnim: '',
		maxDate: todayDate,
		dateFormat: 'dd/mm/yy',
		beforeShow: function(textbox, instance){
			instance.dpDiv.appendTo($('body'));
		}
	});

	function validateForm(myform)
	{
		$.validator.setDefaults({ ignore: '' });
		$('form.'+myform).validate({
			success: function(label) {
				label.addClass("valid");
				$.colorbox.resize();
			},
			showErrors: function() {
				this.defaultShowErrors();
				$.colorbox.resize();
			}
		});
		
		$('form.'+myform+' .btnSubmit').click(function(){			
			$('.'+myform).submit();
			$.colorbox.resize();
		});
		
		$('form.'+myform+' .btnReset').click(function(){
			$('form.'+myform).validate().resetForm();
			document.forms['mainform'].reset();
			$.colorbox.resize();
		});	
	}
}

function setRegisterForm(myform){
		
	validateForm(myform);

	$('.register .custselect').dropkick({
		startSpeed : 0,
		change: function(value, label) {
			$(this).parent().find('input').val(value);
			//$('form.'+myform).validate().element($(this).parent().find('input')); 
		}
	});
	
	$('.dobpicker').datepicker({
		monthNames: monthNamesAry, //['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'],
		changeYear: true,
		changeMonth: true,
		yearRange: (todayDate.getFullYear() - 100) + ':' + todayDate.getFullYear(),
		showAnim: '',
		maxDate: todayDate,
		dateFormat: 'dd/mm/yy',
		beforeShow: function(textbox, instance){
			instance.dpDiv.appendTo($('body'));
		}
	});

	function validateForm(myform)
	{
		$.validator.setDefaults({ ignore: '' });
		$('form.'+myform).validate({
			success: function(label) {
				label.addClass("valid");
				$.colorbox.resize();
			},
			showErrors: function() {
				this.defaultShowErrors();
				$.colorbox.resize();
			}
		});
		
		$('form.'+myform+' .btnSubmit').click(function(){			
			$('.'+myform).submit();
			$.colorbox.resize();
		});
		
		$('form.'+myform+' .btnReset').click(function(){
			$('form.'+myform).validate().resetForm();
			document.forms['registerForm'].reset();
			$.colorbox.resize();
		});
	}
}

function setKnowMoreForm(myform){
		
	validateForm(myform);

	$('.wantToKnowMore .custselect').dropkick({
		startSpeed : 0,
		change: function(value, label) {
			$(this).parent().find('input').val(value);
			//$('form.'+myform).validate().element($(this).parent().find('input')); 
		}
	});

	$('.eventpicker').datepicker({
		monthNames: monthNamesAry, //['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'],
		changeYear: true,
		changeMonth: true,
		//yearRange: (todayDate.getFullYear() - 100) + ':' + todayDate.getFullYear(),
		showAnim: '',
		minDate: todayDate,
		dateFormat: 'dd/mm/yy',
		beforeShow: function(textbox, instance){
			instance.dpDiv.appendTo($('body'));
		}	
	});
	
	function validateForm(myform)
	{
		$.validator.setDefaults({ ignore: '' });
		$('form.'+myform).validate({
			success: function(label) {
				label.addClass("valid");
				$.colorbox.resize();
			},
			showErrors: function() {
				this.defaultShowErrors();
				$.colorbox.resize();
			}
		});
		
		$('form.'+myform+' .btnSubmit').click(function(){			
			$('.'+myform).submit();
			$.colorbox.resize();
		});
		
		$('form.'+myform+' .btnReset').click(function(){
			$('form.'+myform).validate().resetForm();
			document.forms['knowMoreform'].reset();
			$.colorbox.resize();
		});
	}
}

function genCityMap() {
	/*<script type="text/javascript">
      var script = '<script type="text/javascript" src="http://google-maps-' +
          'utility-library-v3.googlecode.com/svn/trunk/infobubble/src/infobubble';
      if (document.location.search.indexOf('compiled') !== -1) {
        script += '-compiled';
      }
      script += '.js"><' + '/script>';
      document.write(script);
    </script>*/
	var section;
	var infoBubble;
	var markers = [];
	
	var myLatlng = new google.maps.LatLng(22.307855,114.179768);
	
	var myStyle = [
		{
			featureType: "water",
			elementType: 'all',
			stylers: [ { hue: '#D4D4C9' }, { saturation: -75 }, { lightness: 21 }, { visibility: 'on' } ]
		}
	];
	
	var myStyleType = new google.maps.StyledMapType(myStyle, {name: "hotalICONStyle"});

	var myOptions = {
		zoom: 13,
		center: myLatlng,
		disableDefaultUI: true,
		mapTypeControlOptions: {
			mapTypeIds: [google.maps.MapTypeId.ROADMAP, 'my_style']
		},
		mapTypeId: google.maps.MapTypeId.ROADMAP
	}
	
	var map = new google.maps.Map(document.getElementById("myMap"), myOptions);
	map.mapTypes.set('my_style', myStyleType);
	map.setMapTypeId('my_style');
	
	// Info Window
	if ($('#sectionContainer').hasClass('home')){
		infoBubble = new InfoBubble({
			map: map,
			content: '<div class="gmapInfo home"></div>',
			shadowStyle: 0,
			padding: 0,
			backgroundColor: 'transparent',
			borderRadius: 0,
			arrowSize: 0,
			borderWidth: 0,
			disableAutoPan: false,
			hideCloseButton: true,
			backgroundClassName: 'gmapInfoContainer'
		});
	} else {
		infoBubble = new InfoBubble({
			map: map,
			content: '<div class="gmapInfo"></div>',
			shadowStyle: 0,
			padding: 0,
			backgroundColor: 'transparent',
			borderRadius: 0,
			arrowSize: 0,
			borderWidth: 0,
			disableAutoPan: false,
			hideCloseButton: true,
			backgroundClassName: 'gmapInfoContainer'
		});
		
	}
	
	var hotel = ['Hotel Icon', 22.300855,114.179768, 100, '/images/googlemap/thumb_hotel-icon.png'];
	
	
	// Set Sites Icon function
	function genCatMarker(num) {
		markers = [];
		var data = markerArray[num].data;
		for (var i = 0; i < data.length; i++) {
			setMarkers(map, [data[i].name, data[i].latitude, data[i].longitude, data[i].zIndex, data[i].thumb], data[i], i, 25, 62);
		}
		section = num;
		
		//console.log(markers[2])
	}
	
	// Set Icons function
	function setMarkers(map, locations, data, i, originX, originY) {
		var sites = locations;
		var image = new google.maps.MarkerImage(
			sites[4], 
			null, 
			new google.maps.Point(0, 0), 
			new google.maps.Point(originX, originY),
			null
		);
		var myLatLng = new google.maps.LatLng(sites[1], sites[2]);
		var marker = new google.maps.Marker({
			position: myLatLng,
			map: map,
			icon: image,
			title: sites[0],
			zIndex: sites[3]
		});
		
		marker.data = data;
		
		markerClickAction(marker, i);
		
		markers.push(marker);
	}
	
	// Marker click function
	function markerClickAction(marker, i){
		google.maps.event.addListener(marker, 'click', function(){
			if (!this.data)	return;
			//alert(this.data.tel);
			
			$('.siteInfo').prependTo('#gmapContainer');
			$('.gmapInfo').html('');
			$('.siteInfo .website').html('');
			var content = createDiv('', 'content clearfix');
			var img = createImg(this.data.mainVisual, '');
			var closeBtn = createA('javascript:;', '', ' ', '', 'btnClose');
			var contentInfo = createDiv('', 'contentInfo');
			var title = createTag('h4');
			var a = createA(this.data.website, '_blank', this.data.website);
			var p = createTag('p');
			
			$(closeBtn).appendTo(content);
			$(img).appendTo(content);
			$(contentInfo).appendTo(content);
			$(title).html(this.data.name).appendTo(contentInfo);
			$('.siteInfo .address').html(this.data.address);
			$('.siteInfo .tel').html(this.data.tel);
			$(a).appendTo($('.siteInfo .website'));
			if (this.data.website){
				if (!$(a).attr('href').match(/^http/) || !$(a).attr('href').match(/^https/)){
					$(a).attr('href', 'http://' + $(a).attr('href'));
				}
			}
			$('.siteInfo .openingHours').html(this.data.hours);
			if (!this.data.address) {$('.siteInfo .address').hide().prev().hide();} else {$('.siteInfo .address').show().prev().show();}
			if (!this.data.tel) {$('.siteInfo .tel').hide().prev().hide();} else {$('.siteInfo .tel').show().prev().show();}
			if (!this.data.website) {$('.siteInfo .website').hide().prev().hide();} else {$('.siteInfo .website').show().prev().show();}
			if (!this.data.hours) {$('.siteInfo .openingHours').hide().prev().hide();} else {$('.siteInfo .openingHours').show().prev().show();}
			$('.siteInfo').appendTo(contentInfo);
			
			$(p).html(this.data.desc).appendTo(contentInfo);
			
			infoBubble.open(map, marker);
			
			hideMarkers();
			marker.setMap(map);
			mapDraggable(false);
			
			$('.catList a').removeClass('active');
			$('.catList a').eq(i).addClass('active');
			
			setTimeout(function(){
				$(content).appendTo('.gmapInfo');
				$('.gmapInfo a.btnClose').click(function(){
					//alert(section);
					closeInfo(section);
				});
			}, 300);
			
		});
		
	}
	
	// Set Map Draggable or not
	function mapDraggable(isDrag){
		map.setOptions({ draggable : isDrag, scrollwheel : isDrag });
	}
	
	// Close Info Window
	function closeInfo(num){
		mapDraggable(true);
		infoBubble.close(map);
		map.setCenter(myLatlng);
		map.setZoom(13);
		hideMarkers();
		genCatMarker(num);
		setMarkers(map, hotel, '', '', 38, 106);
		$('.siteInfo').prependTo('#gmapContainer');
		$('.catList a').removeClass('active');
	}
	
	// Hide Markers
	function hideMarkers(){
		for (j in markers) {
			markers[j].setMap(null);
		}	
	}
	
	// Zoom function
	function gmapZoom(){
		$('.gmapControls a.btnZoomIn').click(function(){
			map.setZoom(map.zoom+1);
		});
		
		$('.gmapControls a.btnZoomOut').click(function(){
			map.setZoom(map.zoom-1);
		});
	}
	
	// Gen Sites List
	function genSitesList(target){
		$('.catList').html('');
		var title = createTag('h3');
		var info = createDiv('', 'siteList');
		var ul = createTag('ul');
		$(title).html(markerArray[target].name).appendTo($('.catList'));
		$(ul).appendTo(info);
		$(info).appendTo($('.catList'));
		for (var j=0; j < markerArray[target].data.length; j++) {
			var li = createTag('li');
			var a = createA('javascript:;');
			$(a).html(markerArray[target].data[j].name).appendTo(li);
			$(li).appendTo(ul);
		}
	}
	
	// Show Hide Sites List
	function showHideSitesList(){
		var w = $('.catListContainer .shadow').outerWidth();
		$('.catListContainer .btnShowHide').click(function(){
			if ($(this).hasClass('active')){
				$(this).removeClass('active');
				$(this).parent().find('.shadow').animate({
					left: 0
				});
			} else {
				$(this).addClass('active');
				$(this).parent().find('.shadow').animate({
					left: w
				});
			}
		});
	}
	
	// Trigger Marker Action
	function triggerMarker(){
		$('.catList a').each(function(index){		
			$(this).click(function(){
				if ($(this).hasClass('active'))	return;
				google.maps.event.trigger(markers[index], 'click');
			});
		});
	}
	
	showHideSitesList();
	gmapZoom();
	setMarkers(map, hotel, '', '', 38, 106);
	
	// Catergory Nav 
	$('.cityCatNav a').each(function(i){
		$(this).click(function(){
			if ($(this).hasClass('active'))	return;
			
			$('.cityCatNav a').removeClass('active');
			$(this).addClass('active');
			closeInfo(i);
			genSitesList(i);
			
			if($('.siteList')) $('.siteList').jScrollPane();
			//$(this).parent().parent().parent().parent().find('#gmapContainer').attr('class', markerArray[i].name.split(' ').join('').toLowerCase());
			
			$('#gmapContainer').attr('class', markerArray[i].type.split(' ').join('').toLowerCase());
			triggerMarker();
		});
	});
	$('.cityCatNav a:first-child').click();	
}

function genLocationMap() {
	
	var myLatlng = new google.maps.LatLng(22.303855,114.179768);
	
	var myStyle = [
		{
			featureType: "water",
			elementType: 'all',
			stylers: [ { hue: '#D4D4C9' }, { saturation: -75 }, { lightness: 21 }, { visibility: 'on' } ]
		}
	];
	
	var myStyleType = new google.maps.StyledMapType(myStyle, {name: "hotalICONStyle"});

	var myOptions = {
		zoom: 14,
		center: myLatlng,
		disableDefaultUI: true,
		mapTypeControlOptions: {
			mapTypeIds: [google.maps.MapTypeId.ROADMAP, 'my_style']
		},
		mapTypeId: google.maps.MapTypeId.ROADMAP
	}
	
	var map = new google.maps.Map(document.getElementById("myMap"), myOptions);
	map.mapTypes.set('my_style', myStyleType);
	map.setMapTypeId('my_style');
	
	
	var hotel = ['Hotel Icon', 22.300855,114.179768, 100, '/images/googlemap/thumb_hotel-icon.png'];
	
	// Set Icons function
	function setMarkers(map, locations) {
		var sites = locations;
		var image = new google.maps.MarkerImage(
			sites[4], 
			null, 
			new google.maps.Point(0, 0), 
			new google.maps.Point(38, 106),
			null
		);
		var myLatLng = new google.maps.LatLng(sites[1], sites[2]);
		var marker = new google.maps.Marker({
			position: myLatLng,
			map: map,
			icon: image,
			title: sites[0],
			zIndex: sites[3]
		});
	}
	
	// Zoom function
	function gmapZoom(){
		$('.gmapControls a.btnZoomIn').click(function(){
			map.setZoom(map.zoom+1);
		});
		
		$('.gmapControls a.btnZoomOut').click(function(){
			map.setZoom(map.zoom-1);
		});
	}
	
	gmapZoom();
	setMarkers(map, hotel);
}


function showReadMore(){
	$('.offerItem .btnReadMore').each(function(i){
		$(this).click(function(){
			$(this).colorbox({
				//inline:true, overlayClose:false, transition:'fade', href:$('.readMoreContainer').eq(i),
				//onComplete:function(){$('.readMoreContainer').jScrollPane();}	
				inline:true, overlayClose:true, transition:'fade', href:$('.offersDetail').eq(i),scrolling:false,width:($('.offersDetail').css('max-width')),height:('auto'),
				onComplete:function(){/*$('.offersDetail').jScrollPane();$(this).colorbox.resize();*/ }
			});
		});
	});
	
	$('.articleDetails .btnReadMore').each(function(i){
		$(this).click(function(){
			$(this).colorbox({
				inline:true, overlayClose:false, transition:'fade', href:$('.readMoreContainer').eq(i),
				onComplete:function(){$('.readMoreContainer').jScrollPane();}	
				//inline:true, overlayClose:true, transition:'fade', href:$('.offersDetail').eq(i),scrolling:false,width:($('.offersDetail').css('max-width')),height:('auto'),
			});
		});
	});
}


 $(document).ready(function () {
	
	window.addEventListener("orientationchange", function() {
		$.colorbox.close();
	}, false);
	
	if(!checkMobile()){
		window.addEventListener("resize", function() {
		$.colorbox.close();
		},false);
	}
});




function showArticleYearLists(){
	$('.articleYear .yearHeader').click(function(){
		$parent = $(this).parent();
		if($(this).hasClass('opened')){
			$(this).removeClass('opened');			
			$('.articleContent', $parent).slideToggle(function(){
				if(isUnder768){
					$('#sectionContainer').height($('.section').eq(currentSubSection).height()+50);
				}
			});			
		}else{
			$(this).addClass('opened');
			$('.articleContent', $parent).slideToggle(function(){
				if(isUnder768){
					$('#sectionContainer').height($('.section').eq(currentSubSection).height()+50);
				}
			});			
		}
	});
	$('.articleYear:first-child .yearHeader').click();	
}

function facebookLike() {
	var path = location.href;
	//var path = document.domain;
	
	document.write('<div class="fb-like" data-href="' + path + '" data-send="false" data-layout="button_count" data-width="90" data-show-faces="false"></div>');
}

function checkAvailable(arriveID, leaveID)
{
	//Updated on 05/11/2013 by Jason Chan
	var url;
	var lang;
	
	if(!d.getElementById(arriveID) || !d.getElementById(leaveID)) return;

	var arriveDate = d.getElementById(arriveID).value;
	arriveDate = arriveDate.split('/');	// change date format from dd/MM/yyyy to MM/dd/yyyy
	arriveDate = arriveDate[1] + "/" + arriveDate[0] + "/" + arriveDate[2];

	var leaveDate = d.getElementById(leaveID).value;
	leaveDate = leaveDate.split('/');	// change date format from dd/MM/yyyy to MM/dd/yyyy
	if (lang = 'ru-ru')
	{
		leaveDate = leaveDate[1] + "/" + leaveDate[0] + "/" + leaveDate[2];
	}
	else
	{
		
	}

	
	// check if cookie exist
	if (getCookie('website_base#lang'))
	{
		lang = getCookie('website_base#lang');
	}
	// check if language parameter exist
	else if (GetParam('sc_lang'))
	{
		lang = GetParam('sc_lang');
	}
	else
	// set default to "English" if both cookie and parameter don't exist
	{
		lang = 'en-US';
	}
	
	// hardcode change "en" to "en-US"
	if (lang == 'en')
	{
		lang = 'en-US';
	}
	// Change to Uppercase for text after "-"
	if (lang != 'ru-ru')
	{
		var array = lang.split('-');
		lang = array[0] + '-' + array[1].toUpperCase();
	}
	
	url = 'https://gc.synxis.com/rez.aspx?Hotel=51197&Chain=12116&shell=GCF&template=FLEXDEMO&locale=' + lang + '&arrive='+ arriveDate +'&depart='+ leaveDate;
	
	//var url = 'https://gc.synxis.com/rez.aspx?Hotel=51197&Chain=12116&start=availresults&arrive='+ arriveDate +'&depart='+ leaveDate;

	openWindow(url);
}

function openWindow(link) {
	_gaq.push(function() {
		var tracker = _gat._getTrackerByName();  //add name param if needed
		window.open(tracker._getLinkerUrl(link));
	});
	return false;
}

/* phase 2 */
function showProfileMenu(){
	$('#loginPanel').hover(
		function () {
			$(this).addClass('active');
			$('#loginPulldownPanel').show();
		},
		function () {
			$(this).removeClass('active');
			$('#loginPulldownPanel').hide();
		}			
	);
}

function historyTable(){
	if(d.getElementById('history')) $('#history table.historyTable tbody').children(':odd').addClass('even');
}

function iconPointGallery(){
	$('#icon-point .galleryContainer ul').each(function(i){
		if ($(this).find('li').length <= 1) {
			$(this).parent().find('.controls').hide();
			return;
		}
		$(this).cycle({ 
			fx: 'scrollHorz', 
			timeout: 5000,
			speed: 400,
			slideResize: false,
			prev: $(this).parent().find('.prev'),
			next: $(this).parent().find('.next'),
			pager: $(this).parent().find('.galleryNav .center .middle .in'),
			activePagerClass: 'active',
			pagerAnchorBuilder: pagerFactory
		});
	});
	
	function pagerFactory(idx, slide) {
		return '<div><a href="#">'+($(slide).find('img').attr('alt'))+'</a></div>';
	};
}

function iconPointDetails(){
	if(!d.getElementById('icon-point')) return;
	$('tr:odd','#icon-point table.earnPointTable table.activitiesTable').addClass('even');
}

function connectSocialMedia(){
	$('.connectMedias .connectFB').click(function(){
		//alert("connect");
		$(this).colorbox({
			inline:true, overlayClose:false, transition:'fade', href:$('.socialMediaConnection'),
			onComplete:function(){ /*$('#socialMediaConnection').jScrollPane();alert("complete");*/ }
		});			
	});
}

function redeemPopup(){
	$('.redeemBtn.enable').each(function(i){
		$(this).click(function(){
			var itemID = this.id;
			$(this).colorbox({
				inline:true, overlayClose:false, transition:'fade', href:'/forms/RedemptionForm.aspx?item='+encodeURIComponent(itemID),
				iframe:true, width: "450px", height: "605px", scrolling:false, fixed: true,
				//onComplete:function(){ alert('redeemContainer'); }
				onOpen: setColorBoxPlacement
			});
		});
	});	
	
	function setColorBoxPlacement(){
		$('#cboxOverlay').appendTo($('#aspForm'));
		$('#colorbox').appendTo($('#aspForm'));
	}
}

function couponLink() {
	$('.couponStatus.enable').each(function(i){
		$(this).click(function(){
			var couponID = this.id;
			var url = '/forms/DownloadCoupon.aspx?coupon='+couponID;
			//NewWindow(url, 'Download', '480', '320', '0', '0');
			openWindow(url);
		});
	});
}

function shareToSM() {
	$('.shareSMBtns a.btnFBshare').each(function (i) {
		$(this).click(function () {
			$(this).colorbox({
				inline: true, overlayClose: false, transition: 'fade', href: $(this).parent().parent().find('.shareFBPopup'),
				onOpen: setColorBoxPlacement
			});
		});
	});

	$('.shareSMBtns a.btnWeiboshare').each(function (i) {
		$(this).click(function () {
			$(this).colorbox({
				inline: true, overlayClose: false, transition: 'fade', href: $(this).parent().parent().find('.shareWeiboPopup'),
				onOpen: setColorBoxPlacement
			});
		});
	});

	function setColorBoxPlacement() {
		$('#cboxOverlay').appendTo($('#aspForm'));
		$('#colorbox').appendTo($('#aspForm'));
	}
}

function setConnectButtons() {
    $('.connectMedias .connectFB, .btnConnectShare .connectWithFB').each(function (i) {
        $(this).click(function () {
//            if (isIE)
                window.location = fbOAuthUrl;
//            else
//                $(this).colorbox({
//                    inline: true, overlayClose: false, transition: 'fade', href: fbOAuthUrl, iframe: true,
//                    width: "480px", height: "320px", scrolling: false, onOpen: setColorBoxPlacement
//                });
        });
    });

    $('.connectMedias .connectWeibo, .btnConnectShare .connectWithWB').each(function (i) {
        $(this).click(function () {
//            if (isIE)
                window.location = wbOAuthUrl;
//            else
//                $(this).colorbox({
//                    inline: true, overlayClose: false, transition: 'fade', href: wbOAuthUrl, iframe: true,
//                        width: "600px", height: "360px", scrolling: false, onOpen: setColorBoxPlacement
//                });
        });
    });

    function setColorBoxPlacement() {
        $('#cboxOverlay').appendTo($('#aspForm'));
        $('#colorbox').appendTo($('#aspForm'));
    }
}

String.prototype.trim = function () {
    return this.replace(/^\s+|\s+$/g, '');
}

function getCookie(c_name)
{
	if (document.cookie.length>0)
	{
		c_start=document.cookie.indexOf(c_name + "=");
		if (c_start!=-1)
		{
			c_start=c_start + c_name.length+1;
			c_end=document.cookie.indexOf(";",c_start);
			if (c_end==-1) c_end=document.cookie.length;
			return unescape(document.cookie.substring(c_start,c_end));
		}
	}
	return "";
}
var currentSubSection = 0;
$(document).ready(function(){	
	if(isIELower9){
		$('body').addClass('IE8');
	};
	if($('#header #mainnav a.highlighted').length>=1){		
		$('.mobile_title').html($('#header #mainnav a.highlighted').html().toUpperCase());
	}else if (currentDisplayTitle != ''){
		if ($('.mobile_title').length >= 1)	$('.mobile_title').html(currentDisplayTitle.toUpperCase());
	}else{
		if ($('.mobile_title').length >= 1)	$('.mobile_title').html(currentPageTitle.toUpperCase());
	}

	$('.mobile_nav').html($('.reservation').html()+$('#mainnav').html());
	
	var globalMobileMenu = $('<div class="globalMobileMenu"></div>').appendTo('.mobile_nav');
	$('.topnav > a').each(function(i){
		if(i>0 && i<3){$(this).clone().appendTo(globalMobileMenu);}
	})
	
    $('.infoLinks > li > a').each(function(i){
		if(i>0 && i<4){$(this).clone().appendTo(globalMobileMenu);}
	})
    
	$('.mobile_nav a').each(function(i){
		$(this).html($(this).html().toUpperCase());
	})
	
	$('.mobile_nav .reservationDate').remove();
	$('.btn_mobile').bind('click', openMobileMenu);
	$(window).bind('resize', resizeMenu);
	resizeMenu();

	if(isUnder768){
		while($('.section').eq(currentSubSection).css('display')=='none'){
			currentSubSection++;
		}
		$('.section').stop().eq(currentSubSection).animate({'left':0});
		$('#sectionContainer').height($('.section').eq(currentSubSection).height()+50);
	}
	$('#left').bind('click', goLeft);
	$('#right').bind('click', goRight);

    //for mobile language
	var langList = ['ENGLISH', '繁體中文', '简体中文', '日本語', '한국어', 'русский'];
	var langSFList = ['en', 'zh-tw', 'zh-cn', 'ja-jp', 'ko-kr', 'ru-ru'];	

	var ulStringTemp = '<ul>';
	for (var i = 0; i < langList.length; i++) {	    
	    ulStringTemp += '<li><a href="javascript:changeLanguage(\'' + langSFList[i] + '\')">' + langList[i] + '</a></li>';
	}
	ulStringTemp += '</ul>';
	var langMobileMenu = $('<div class="globalMobileLangMenu">' + ulStringTemp + '</div>').appendTo('.mobile_nav');

	//$('.langList > a').each(function(i){
		//$(this).clone().appendTo(langMobileMenu);
	//})
	
})
var subOpen = false;
function openMobileMenu(){
	if(subOpen){
		subOpen=false;
		$('#header').stop().animate({'left':0},400);
	}else{
		subOpen=true;
		var myWidth = -($('#mainContainer').width()-39);
		$('#header').stop().animate({'left':myWidth},400);
	}
}
var isUnder768 = false;
var arrowChecked = false;
function resizeMenu(){
	if($(window).width()>1023){
		if(isUnder768){
			$('.home .galleryContainer').attr('style', '');
			$('.galleryHolder').attr('style', '');
			isUnder768 = false;
			$('.section').stop();
			$('.section').css({'left':'auto'});
		}
		$('#header').attr('style','');
		$('#sectionContainer').height('auto');
	}else{
		var galleryHeight = ($(window).width()*(480/980)) + 'px !important';
		$('.home .galleryContainer').attr('style', 'height:'+galleryHeight);
		$('.galleryHolder').attr('style', 'height:'+galleryHeight);
		if(!arrowChecked){
			arrowChecked = true;
			var showedSection = $('.section').length;
			$('.section').each(function(){
				if($(this).css('display')=='none'){
					showedSection--;
				}
			})
			if(showedSection<=1){
				$('#rightHolder').hide();
				$('#leftHolder').hide();
			};	
		}
		if(!isUnder768){
			isUnder768 = true;
			if(currentSubSection<0)currentSubSection=0;
			setTimeout(function(){
				if($('.section').eq(currentSubSection).css('display')=='none'){
					currentSubSection=0;
				}
				while($('.section').eq(currentSubSection).css('display')=='none'){
					currentSubSection++;
				}
				$('.section').each(function(i){
					if(i<currentSubSection){
						$(this).stop().animate({'left':'-100%'},0);
					}else if(i>currentSubSection){
						$(this).stop().animate({'left':'100%'},0);
					}else if(i==currentSubSection){
						$(this).stop().animate({'left':'0%'},0);
					}
				});
			}, 100);
		}
		if(subOpen){
			var myWidth = -($('#mainContainer').width()-39);
			$('#header').stop().animate({'left':myWidth},0);
		}
		$('.mobile_nav').css({'max-height':$(window).height()})
		$('#sectionContainer').height($('.section').eq(currentSubSection).height()+50);
	}
}

function goLeft(){
	if(currentSubSection>0){
		$('.section').eq(currentSubSection).stop().animate({'left':'100%'});
		var oldSubSection = currentSubSection;
		currentSubSection--;
		if($('.section').eq(currentSubSection).css('display')=='none'){currentSubSection--;}
		if(currentSubSection<0)currentSubSection = oldSubSection;
		$('.section').eq(currentSubSection).stop().animate({'left':'0'});
//		$('body, html').stop().animate({'scrollTop':0});
		$('#sectionContainer').height($('.section').eq(currentSubSection).height()+50);
	}
	showHideArrow();
}
function goRight(){
	if(currentSubSection<$('.section').length-1){
		$('.section').eq(currentSubSection).stop().animate({'left':'-100%'});
		currentSubSection++;
		if($('.section').eq(currentSubSection).css('display')=='none'){currentSubSection++;}
		$('.section').eq(currentSubSection).stop().animate({'left':'0'});
//		$('body, html').stop().animate({'scrollTop':0});
		$('#sectionContainer').height($('.section').eq(currentSubSection).height()+50);
	}
	showHideArrow();
}

function showHideArrow(){
	var sectId = 0;
	if($('.section').eq(0).css('display')=='none'){sectId = 1};
	if (currentSubSection != sectId)
	{
		$('#left').show();
	}
	else
	{
		$('#left').hide();
	}
	if (currentSubSection != $('.section').length-1)
	{
		$('#right').show();
	}
	else
	{
		$('#right').hide();
	}
}

function resizeLightBoxIframe(){
	$(document).ready(function(){
	    parent.$.colorbox.resize({
	        innerWidth:$('body > form').width(),
	        innerHeight:$('body > form').height()
	    });
	});
}