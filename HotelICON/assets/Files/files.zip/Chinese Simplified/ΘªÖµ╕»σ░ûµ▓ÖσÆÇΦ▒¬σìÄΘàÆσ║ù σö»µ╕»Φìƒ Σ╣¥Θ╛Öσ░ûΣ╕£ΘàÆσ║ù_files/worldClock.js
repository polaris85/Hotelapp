function worldClock(zone, region){
	var dst = 0;
	var time = new Date();
	var curTimeArray = $('#timeContainer').html().split(':');
	time.setHours(curTimeArray[0]);
	time.setMinutes(curTimeArray[1]);
	time.setSeconds(curTimeArray[2]);
	var gmtMS = time.getTime() + 1000 + (time.getTimezoneOffset() * 60000);
	var gmtTime = new Date(gmtMS);
	var day = gmtTime.getDate();
	var month = gmtTime.getMonth();
	var year = gmtTime.getYear();
	
	if(year < 1000){
		year += 1900
	}
	var monthArray = new Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")
	var monthDays = new Array("31", "28", "31", "30", "31", "30", "31", "31", "30", "31", "30", "31")
	if (year%4 == 0){
	monthDays = new Array("31", "29", "31", "30", "31", "30", "31", "31", "30", "31", "30", "31")
	}
	if(year%100 == 0 && year%400 != 0){
	monthDays = new Array("31", "28", "31", "30", "31", "30", "31", "31", "30", "31", "30", "31")
	}

	var hr = gmtTime.getHours() + zone
	var min = gmtTime.getMinutes()
	var sec = gmtTime.getSeconds()

	if (hr >= 24){
	hr = hr-24
	day -= -1
	}
	if (hr < 0){
	hr -= -24
	day -= 1
	}
	if (hr < 10){
	hr = " " + hr
	}
	if (min < 10){
	min = "0" + min
	}
	if (sec < 10){
	sec = "0" + sec
	}
	if (day <= 0){
	if (month == 0){
		month = 11
		year -= 1
	}
	else{
		month = month -1
	}
	day = monthDays[month]
	}
	if(day > monthDays[month]){
		day = 1
		if(month == 11){
			month = 0
			year -= -1
		}
		else{
			month -= -1
		}
	}

	if (dst == 1){
			hr -= -1
			if (hr >= 24){
			hr = hr-24
			day -= -1
		}

		if (hr < 10){
			hr = " " + hr
		}
		if(day > monthDays[month]){
			day = 1
			if(month == 11)
			{
				month = 0
				year -= -1
			}
			else{
				month -= -1
			}
		}
		return hr + ":" + min + ":" + sec + " DST"
	}
		else{
		return hr + ":" + min + ":" + sec
		}
}

function worldClockZone(){
	var div = d.getElementById('timeContainer');
	div.innerHTML = worldClock(8, "HongKong");
	setTimeout("worldClockZone()", 1000)
}

$(document).ready( function() {
	worldClockZone();
});