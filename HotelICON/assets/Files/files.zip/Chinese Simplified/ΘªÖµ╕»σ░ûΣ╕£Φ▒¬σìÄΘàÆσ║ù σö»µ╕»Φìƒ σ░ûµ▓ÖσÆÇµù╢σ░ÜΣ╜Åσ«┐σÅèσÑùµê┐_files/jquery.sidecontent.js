(function($)
{
	// This script was written by Steve Fenton
	// http://www.stevefenton.co.uk/Content/Jquery-Side-Content/
	// Feel free to use this jQuery Plugin
	// Version: 3.0.2
    // Contributions by:

	var classModifier = "";
	var sliderCount = 0;
	var sliderWidth = "280px";
	var sliderHeight = "auto";

	var attachTo = "rightside";

	var totalPullOutHeight = 0;
	var totalPullOutWidth = 0;

	function CloseSliders (thisId) {
		// Reset previous sliders
		for (var i = 0; i < sliderCount; i++) {
			var sliderId = classModifier + "_" + i;
			var pulloutId = sliderId + "_pullout";

			// Only reset it if it is shown
			if (attachTo == "leftside" || attachTo == "rightside"){
				if ($("#" + sliderId).width() > 0) {
					if (sliderId == thisId) {
						// They have clicked on the open slider, so we'll just close it
						showSlider = false;
					}
					// Close the slider
					$("#" + sliderId).animate({
						width: "0px"
					}, 1500);

					// Reset the pullout
					$("#" + pulloutId).animate({
						width: "37px"
					}, 1500);
					if (attachTo == "leftside"){
						if (navigator.userAgent.toLowerCase().indexOf('msie 8') != -1){
							$(".tagnametitle").animate({
								left: "2px"
							}, 1500);
						}
						else {
							$(".tagnametitle").animate({
								left: "-78px"
							}, 1500);
						}
					}
				}
			}
			else {
				if ($("#" + sliderId).height() > 0) {
					if (sliderId == thisId) {
						// They have clicked on the open slider, so we'll just close it
						showSlider = false;
					}

					// Close the slider
					$("#" + sliderId).animate({
						height: "0px"
					}, 1500);

					if (attachTo == "bottomleft" || attachTo == "bottomright") {
						$("#" + pulloutId).animate({
							bottom: "0px"
						}, {
							duration: 1500,
							complete: function(){
								if ($("#notify-icon")){
									$("#notify-icon").show();
								}
							}
						});
					}
				}
			}
		}
	}

	function ToggleSlider () {

		var rel = $(this).attr("rel");

		var thisId = classModifier + "_" + rel;
		var thisPulloutId = thisId + "_pullout";
		var showSlider = true;

		if (attachTo == "leftside" || attachTo == "rightside"){
			if ($("#" + thisId).width() > 0) {
				showSlider = false;
			}
		}
		else {
			if ($("#" + thisId).height() > 0) {
				showSlider = false;
			}
		}

		CloseSliders(thisId);

		if (showSlider) {
			// Open this slider
			if (attachTo == "leftside" || attachTo == "rightside"){
				$("#" + thisId).animate({
					width: sliderWidth
				}, 1500);
			}
			else {
				sliderHeight = $(".fms-side").outerHeight(false);
				$("#" + thisId).animate({
					height: sliderHeight
				}, 1500);
			}
			// Move the pullout
			if (attachTo == "leftside" || attachTo == "rightside"){
				$("#" + thisPulloutId).animate({
					width: "318px"
				}, 1500);

				if (attachTo == "leftside"){
					if (navigator.userAgent.toLowerCase().indexOf('msie 8') != -1){
						// IE 8
						$(".tagnametitle").animate({
							left: "282px"
						}, 1500);
					}
					else {
						$(".tagnametitle").animate({
							left: "202px"
						}, 1500);
					}
				}
			}
			else {
				if (attachTo == "bottomleft" || attachTo == "bottomright") {
					$("#" + thisPulloutId).animate({
						bottom: sliderHeight
					}, {
						duration: 1500,
						complete: function(){
							if ($("#notify-icon")){
								$("#notify-icon").hide();
							}
						}
					});
				}
			}
		}

		return false;
	};

	$.fn.sidecontent = function (settings) {

		var config = {
			classmodifier: "sidecontent",
			attachto: "rightside",
			width: "250px",
			opacity: "1",
			pulloutpadding: "5",
			textdirection: "vertical",
			clickawayclose: false
		};

		if (settings) {
			$.extend(config, settings);
		}

		return this.each(function () {

			$This = $(this);

			// Hide the content to avoid flickering
			$This.css({ opacity: 0 });

			classModifier = config.classmodifier;
			sliderWidth = config.width;
			attachTo = config.attachto;

			var sliderId = classModifier + "_" + sliderCount;
			var sliderTitle = config.title;

			// Get the title for the pullout
			//sliderTitle = $This.attr("title");

			// Start the totalPullOutHeight with the configured padding
			if (totalPullOutHeight == 0) {
				totalPullOutHeight += parseInt(config.pulloutpadding);
			}

			if (config.textdirection == "vertical") {
				var newTitle = "";
				var character = "";
				newTitle = "<div class='tagnametitle'>" + sliderTitle + "</div>";
				sliderTitle = newTitle;
			}

			// Wrap the content in a slider and add a pullout
			if (attachTo == "leftside" || attachTo == "rightside"){
				$This.wrap('<div class="' + classModifier + ' '+classModifier+'_hoz" id="' + sliderId + '"></div>').wrap('<div style="width: ' + sliderWidth + '"></div>');
				$("#" + sliderId).before('<div class="' + classModifier + 'pullout '+classModifier+'pullout_hoz" id="' + sliderId + '_pullout" rel="' + sliderCount + '">' + sliderTitle + '</div>');
			}
			else {
				$This.wrap('<div class="' + classModifier + ' '+classModifier+'_ver" id="' + sliderId + '"></div>').wrap('<div style="width: ' + sliderWidth + '; height: ' + sliderHeight + '"></div>');

				$("#" + sliderId).before('<div class="' + classModifier + 'pullout '+classModifier+'pullout_ver" id="' + sliderId + '_pullout" rel="' + sliderCount + '">' + sliderTitle + '</div>');
			}

			if (config.textdirection == "vertical") {
				$("#" + sliderId + "_pullout span").css({
					display: "block",
					textAlign: "center"
				});
			}

			// Hide the slider
			if (attachTo == "leftside" || attachTo == "rightside"){
				$("#" + sliderId).css({
					position: "absolute",
					overflow: "hidden",
					top: "0px",
					width: "0px",
					zIndex: "1",
					opacity: config.opacity
				});
			}
			else {
				$("#" + sliderId).css({
					position: "absolute",
					overflow: "hidden",
					bottom: "21px",
					height: "0px",
					zIndex: "1",
					opacity: config.opacity
				});
			}

			// For left-side attachment
			if (attachTo == "leftside") {
				$("#" + sliderId).css({
					left: "0px"
				});
			} else if (attachTo == "rightside") {
				$("#" + sliderId).css({
					right: "0px"
				});
			} else if (attachTo == "bottomleft") {
				$("#" + sliderId).css({
					left: "10px"
				});
			} else if (attachTo == "bottomright") {
				$("#" + sliderId).css({
					right: "10px"
				});
			}

			// Set up the pullout
			if (attachTo == "leftside" || attachTo == "rightside"){
				$("#" + sliderId + "_pullout").css({
					position: "absolute",
					top: totalPullOutHeight + "px",
					zIndex: "1000",
					cursor: "pointer",
					opacity: config.opacity
				})
			}
			else {
				$("#" + sliderId + "_pullout").css({
					position: "absolute",
					bottom: totalPullOutHeight + "px",
					zIndex: "1000",
					cursor: "pointer",
					opacity: config.opacity
				})
			}

			try {
				$("#" + sliderId + "_pullout").live("click", ToggleSlider);
			}
			catch (e){
				$("#" + sliderId + "_pullout").on("click", ToggleSlider);
			}

			if (attachTo == "leftside" || attachTo == "rightside"){
			 	var pulloutWidth = $("#" + sliderId + "_pullout").width();
			 	// For left-side attachment
				if (attachTo == "leftside") {
					/*
					  if (navigator.userAgent.toLowerCase().indexOf('msie 8') == -1){
						$("#" + sliderId + "_pullout").css({
							left: "0px",
							width: pulloutWidth + "px"
						});
					  }
					  else {
					*/
					$("#" + sliderId + "_pullout").css({
						left: "0px",
						width: "37px"
					});
					//  }
				} else {
					$("#" + sliderId + "_pullout").css({
						right: "0px",
						width: "37px"
					});
				}
			}
			else {
				var pulloutHeight = $("#" + sliderId + "_pullout").height();
				$("#" + sliderId + "_pullout").css({
					bottom: "0px",
					height: pulloutHeight + "px"
				});

				// For bottom attachment
				if (attachTo == "bottomleft") {
					$("#" + sliderId + "_pullout").css({
						//left: (10 + ((parseInt(sliderWidth, 10) - parseInt($("#" + sliderId + "_pullout").width(), 10)) / 2)) + "px"
						left: "10px"
					});
				} else if (attachTo == "bottomright") {
					$("#" + sliderId + "_pullout").css({
						right: "10px"
					});
				}
			}

			if (attachTo == "leftside" || attachTo == "rightside"){
				totalPullOutHeight += parseInt($("#" + sliderId + "_pullout").height());
				totalPullOutHeight += parseInt(config.pulloutpadding);

				var suggestedSliderHeight = totalPullOutHeight;// + 30;
				if (suggestedSliderHeight > $("#" + sliderId).height()) {
					$("#" + sliderId).css({
						height: suggestedSliderHeight + "px"
					});
				}
			}
			else {
				totalPullOutWidth += parseInt($("#" + sliderId + "_pullout").width());
				totalPullOutWidth += parseInt(config.pulloutpadding);

				var suggestedSliderWidth = totalPullOutWidth + 30;
				if (suggestedSliderWidth > $("#" + sliderId).width()) {
					$("#" + sliderId).css({
						width: suggestedSliderWidth + "px"
					});
				}
			}

			if (config.clickawayclose) {
				/*
				$("body").click( function () {
					CloseSliders("");
				});
				*/
			}

			// Put the content back now it is in position
			$This.css({ opacity: 1 });

			sliderCount++;
		});

		return this;
	};
})(jQuery);