function FMS (data){	
	var fmscode = data;
	var webservice_url = "http://webstergy.com.sg/fms/services.php";
	var rightpullout_img = "http://webstergy.com.sg/fms/public/notify/images/limited-time-offer-r.png"
	var fmsxmlhttp;
	var slidefrom;

	if(window.XDomainRequest) {
		fmsxmlhttp = new XDomainRequest();
		fmsxmlhttp.onload = renderfms;
	}
	else if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
		fmsxmlhttp = new XMLHttpRequest();
	}
	else {// code for IE6, IE5
		fmsxmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}

	this.setCode = function (data) {
		fmscode = data;
	}
	this.getCode = function () {
		return fmscode;
	}

	this.load = function () {
		window.addEventListener ?
		window.addEventListener("load",initFMS,false) :
		window.attachEvent && window.attachEvent("onload",initFMS);
	}

	function initFMS() {
		var loaded=0;
		var loadJquery = false;

		try {
			if (typeof jQuery != 'undefined') {
				var div=document.createElement("div");
				div.setAttribute("id", "fmsjquery");
				div.setAttribute("style", "display: none");
				div.innerHTML = jQuery.fn.jquery;
				document.getElementsByTagName("body")[0].appendChild(div);
				
				var arr = jQuery.fn.jquery.split('.');
				if(arr[0] == 1 && arr[1] >= 9){ 	}
				else {
					loadJquery = true;
				}
				//loadJquery = (jQuery.fn.jquery == "1.4" || jQuery.fn.jquery == "1.6.1" || jQuery.fn.jquery == "1.2.6");
			}

			if (typeof jQuery == 'undefined' || loadJquery) {
				var newscript = document.createElement('script');
				newscript.type = 'text/javascript';
				newscript.async = true;
				newscript.src = 'http://code.jquery.com/jquery-1.9.1.min.js';

				newscript.onreadystatechange = function () {
					if (newscript.readyState == 'complete' || newscript.readyState == 'loaded') {
						loadscript2();
						loaded=1;
					}
				}
				if (loaded==0){
					newscript.onload = function() {
						
						jQuery.noConflict();
						if (typeof(window.$) === 'undefined') { window.$ = jQuery; }
						loadscript2();
					};
				}
				(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(newscript);
			}
			else {
				
				jQuery.noConflict();
				if (typeof(window.$) === 'undefined') { window.$ = jQuery; }
				loadscript2();
			}
		}
		catch (e) {	
			var div=document.createElement("div");
				div.setAttribute("id", "fms");
				div.setAttribute("style", "display: none");
				div.innerHTML = e.message;
				document.getElementsByTagName("body")[0].appendChild(div);
		}
	}

	function loadscript2(){
		var loaded=0;

		try {
			if (typeof jQuery.ui == 'undefined') {
				var newscript = document.createElement('script');
				newscript.type = 'text/javascript';
				newscript.async = true;
				newscript.src = 'http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.18/jquery-ui.js';

				newscript.onreadystatechange = function () {
					if (newscript.readyState == 'complete' || newscript.readyState == 'loaded') {
						loadscript3();
						loaded=1;
					}
				}
				if (loaded==0){
					newscript.onload = function() {
						loadscript3();
					};
				}
				(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(newscript);
			}
			else {
				loadscript3();
			}
		}
		catch (e) { }
	}

	function loadscript3(){
		var loaded=0;

		try {
			if (!window.PIE && navigator.userAgent.toLowerCase().indexOf('msie 8') != -1) {
				var newscript = document.createElement('script');
				newscript.type = 'text/javascript';
				newscript.async = true;
				newscript.src = 'http://webstergy.com.sg/fms/public/notify/PIE/PIE.js';

				newscript.onreadystatechange = function () {
					if (newscript.readyState == 'complete' || newscript.readyState == 'loaded') {
						loadscript4();
						loaded=1;
					}
				}
				if (loaded==0){
					newscript.onload = function() {
						loadscript4();
					};
				}
				(document.getElementsByTagName('head')[0]||document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(newscript);
			}
			else {
				loadscript4();
			}
		}
		catch (e) {}
	}

	function loadscript4(){
		var loaded=0;

		try {
			var newscript = document.createElement('script');
			newscript.type = 'text/javascript';
			newscript.async = true;
			newscript.src = 'http://webstergy.com.sg/fms/public/notify/jquery.sidecontent.js?v=1.3';

			newscript.onreadystatechange = function () {
				if (newscript.readyState == 'complete' || newscript.readyState == 'loaded') {
					loadfms();
					loaded=1;
				}
			}
			if (loaded==0){
				newscript.onload = function() {
					loadfms();
				};
			}
			(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(newscript);
		}
		catch (e) {}
	}

	function loadfms(){
	    try {
			if(window.XDomainRequest) {
				if (fmscode != '') { webservice_url += "?fmscode="+fmscode; }
				webservice_url += "&host="+ location.hostname+"&url="+location;
			}
			else {
				if (fmscode != '') { webservice_url += "?fmscode="+fmscode;}
			}

			fmsxmlhttp.open('POST', webservice_url, true);
		    if(!window.XDomainRequest) {
				fmsxmlhttp.setRequestHeader('Content-type','application/x-www-form-urlencoded');
			}
			fmsxmlhttp.send();
		}
		catch (e){
		}
	}

	function renderfms(){
		try {
			var div=document.createElement("div");
			div.setAttribute("id", "fmsrender");
			div.innerHTML = fmsxmlhttp.responseText;
			document.getElementsByTagName("body")[0].appendChild(div);

			var public_url = jQuery("#fms_public_url").val();
			var notify_id = jQuery("#fms_notify_id").val();
			
			jQuery(".ui-pnotify-text").find("a").not('.ui-pnotify-img').each(function() {
				var url = jQuery(this).attr("href");
				url = public_url + "trackpromo.php?promo_id="+notify_id+"&url="+encodeURIComponent(url);

				jQuery(this).attr("href", url);
				jQuery(this).attr("target", "_new");
			});

			slidefrom = jQuery("#sidecontent_slidefrom").val();
			var tagname = jQuery("#sidecontent_tagname").val();

			jQuery(".fms-side").sidecontent({
					classmodifier: "sidecontent",
					attachto: slidefrom,
					pulloutpadding: "5",
					width: "280px",
					textdirection: "vertical",
					title: tagname
			});
			
			var sidecontent_css_backgroundcolor = jQuery("#sidecontent_css_background-color").val();
			var sidecontent_css_color = jQuery("#sidecontent_css_color").val();
			var sidecontent_css_fontfamily = jQuery("#sidecontent_css_font-family").val();
			var sidecontent_css_fontsize = jQuery("#sidecontent_css_font-size").val()+"px";
			var sidecontent_autoshow = jQuery("#sidecontent_autoshow").val();
			var pullout_css_backgroundcolor = jQuery("#sidecontent_tagbgcolor").val();

			jQuery(".sidecontent").css("background-color",sidecontent_css_backgroundcolor);
			jQuery(".sidecontent a").css("color",sidecontent_css_color);

			jQuery(".fms-side").css({
				"font-family": sidecontent_css_fontfamily,
				"color": sidecontent_css_color,
				"font-size":sidecontent_css_fontsize,
				"min-height":jQuery(".sidecontentpullout").height()
			});
			jQuery(".fms-side p").css({
				"font-family": sidecontent_css_fontfamily,
				"color": sidecontent_css_color,
				"font-size":sidecontent_css_fontsize
			});

			if (slidefrom == 'leftside') {
				jQuery(".sidecontentpullout").css({
					"left":"0px",
					"border-radius": "0px 10px 10px 0px",
					"border-left": "none",
					"border-right": "solid 2px #fff7e5",
					"background-color": pullout_css_backgroundcolor,
					"background-position": "right"
				});

				jQuery(".tagnametitle").css("left","-78px");
				if (navigator.userAgent.toLowerCase().indexOf('msie 8') != -1){
					jQuery(".tagnametitle").css({
					   "width": "auto",
					   "top": "auto",
					   "margin-top": "auto",
					   "left": "5px"
					});
					jQuery(".tagnametitle").attr("style", jQuery(".tagnametitle").attr("style") + ";-ms-writing-mode:tb-rl");
				}
			}
			else {
				if (slidefrom == 'rightside') {
					jQuery(".sidecontentpullout").css({
						background: "url("+rightpullout_img+")",
						"background-color": pullout_css_backgroundcolor
					});

					if (navigator.userAgent.toLowerCase().indexOf('msie 8') != -1){
						// IE 8
						jQuery(".tagnametitle").css({
						   "width": "auto",
						   "top": "auto",
						   "margin-top": "auto",
						   "left": "15px"
						});
						jQuery(".tagnametitle").attr("style", jQuery(".tagnametitle").attr("style") + ";-ms-writing-mode:tb-rl");
					}
				}
				else {
					jQuery(".sidecontentpullout").css("display","none");
				}
			}

			if (jQuery(".fms-side").find("img").length > 0){
				if (slidefrom =='leftside' || slidefrom=='rightside'){
					window.setTimeout(function(){
						jQuery(".sidecontent").css("margin-top", "-"+(parseInt(jQuery(".fms-side").outerHeight(true), 10 )/2).toString()+"px");
					}, 1000);
				}
			}
			else {
				if (slidefrom =='leftside' || slidefrom=='rightside'){
					jQuery(".sidecontent").css("margin-top", "-"+(parseInt(jQuery(".fms-side").outerHeight(true), 10 )/2).toString()+"px");
				}
			}

			if (sidecontent_autoshow == 1){
				if (jQuery(".fms-side").find("img").length > 0){
					jQuery(".fms-side img").load(function(){
						if (jQuery('#sidecontent_0_pullout')){
							window.setTimeout(function(){jQuery('#sidecontent_0_pullout').click();}, 1000);
						}
					});
				}
				else {
					window.setTimeout(function(){jQuery('#sidecontent_0_pullout').click();}, 2000);
				}
			}

			if (window.PIE) {
				try{
					jQuery(".sidecontentpullout").each(function() {
						PIE.attach(this);
					});
				} catch (e) {}
			}
		}
		catch (ex) { }
	}

	fmsxmlhttp.onreadystatechange=function()
	{
	    try{
		    if (fmsxmlhttp.readyState==4 && fmsxmlhttp.status==200) {
			    renderfms();
		    }
	 	}
	 	catch (e){ }
	}
}


